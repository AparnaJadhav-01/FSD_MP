from django.db import models
from django.shortcuts import render, redirect
from listings import models
from apts.filters import AptFilter
# from .choices import price_choices, bedroom_choices, state_choices

# Create your views here.

def home(request):

    rep1 = models.Listing.objects.all()
    context={
        'listings':rep1
    }
    return render(request, 'apts/home.html',context)


def searchform(request):
    qs = models.Listing.objects.all()
    filt= AptFilter(request.GET,queryset=qs)
    print ("hiii\nhiiii\nhiiiii\nhiiii")
    context ={
      'filter':filt
    }
    print(filt.qs)
    return render(request, "apts/searchflat.html",context)

# def searchform(request):
#     rooms = request.GET.get('bedrooms', None)
#     price = request.GET.get('price', None)

#           # The base query takes all apartments
#     apartments = models.Listing.objects.all()

#           # If a filter param is passed, we use it to filter
#     if rooms:
#         apartments = apartments.filter(rooms=rooms)
#     if price:
#         apartments = apartments.filter(price__lte=price)
    
#     print("hiiiiiiiiiiiii\n",apartments)
#     context ={
#       'filter':apartments
#     }

#     return render(request, "apts/searchflat.html",context)