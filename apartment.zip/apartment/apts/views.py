from django.db import models
from django.shortcuts import render
from listings import models
from .choices import price_choices, bedroom_choices, state_choices

# Create your views here.

def home(request):

    rep1 = models.Listing.objects.all()
    context={
        'listings':rep1
    }
    return render(request, 'apts/home.html',context)

def is_valid_queryparam(param):
    return param != '' and param is not None

def search(request):
  queryset_list = models.Listing.objects.order_by('-list_date')

  # Keywords
#   if 'keywords' in request.GET:
#     keywords = request.GET['keywords']
#     if keywords:
#       queryset_list = queryset_list.filter(description__icontains=keywords)

  # City
  if 'city' in request.GET:
    city = request.GET['city']
    if city:
      queryset_list = queryset_list.filter(city__iexact=city)

  # State
#   if 'state' in request.GET:
#     state = request.GET['state']
#     if state:
#       queryset_list = queryset_list.filter(state__iexact=state)

  # Bedrooms
  if 'bedrooms' in request.GET:
    bedrooms = request.GET['bedrooms']
    if bedrooms:
      queryset_list = queryset_list.filter(bedrooms__lte=bedrooms)

  # Price
  if 'price' in request.GET:
    price = request.GET['price']
    if price:
      queryset_list = queryset_list.filter(price__lte=price)

  context = {
    'city_choices': city_choices,
    'bedroom_choices': bedroom_choices,
    'price_choices': price_choices,
    'listings': queryset_list,
    'values': request.GET
  }

  return render(request, 'listings/search.html', context)


def filter(request):
    qs = models.Listing.objects.all()
    category = request.GET.get('rent')
    reviewed = request.GET.get('reviewed')
    not_reviewed = request.GET.get('notReviewed')

    if is_valid_queryparam(category) and category != 'Choose...':
        qs = qs.filter(categories__name=category)

    if reviewed == 'on':
        qs = qs.filter(reviewed=True)

    elif not_reviewed == 'on':
        qs = qs.filter(reviewed=False)

    return qs